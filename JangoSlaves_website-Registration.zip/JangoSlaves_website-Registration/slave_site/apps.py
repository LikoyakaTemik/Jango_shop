from django.apps import AppConfig


class SlaveSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'slave_site'
